
# Import libraries
import pandas as pd
from pathlib import Path
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import GroupShuffleSplit

# Find the folder containing RNN.py
folder_path = Path(__file__).resolve().parent

# Load the dataset
df = pd.read_csv(
    folder_path / "Project_448.csv",
    encoding="cp1252"
)

# Remove missing values
df = df.dropna().reset_index(drop=True)

# Separate the text responses and LLM names
x = df["LLM_Output"]
y = df["LLM_Name"]

# Convert LLM names into numerical labels
encoder = LabelEncoder()
y = encoder.fit_transform(y)

print("Total Responses:", len(x))
print("LLM Classes:", encoder.classes_)

# Training and Testing Split

# Group responses by their original questions
groups = df["LLM_Input"].str.strip()

print("Unique Questions:", groups.nunique())

# 80% training, 20% testing
splitter = GroupShuffleSplit(
    n_splits=1,
    test_size=0.20,
    random_state=42
)

# Generate training and testing indices
train_idx, test_idx = next(
    splitter.split(x, y, groups=groups)
)

# Split the responses
x_train = x.iloc[train_idx]
x_test = x.iloc[test_idx]

# Split the corresponding labels
y_train = y[train_idx]
y_test = y[test_idx]

print("Training Responses:", len(x_train))
print("Testing Responses:", len(x_test))



import re
import numpy as np
from collections import Counter

# Break responses into tokens
def sentence_tokenize(text):
    return re.findall(r"\w+|[^\w\s]", text.lower())

# Count tokens in the training responses
word_counts = Counter()

for response in x_train:
    word_counts.update(sentence_tokenize(response))

# Create vocabulary
vocab = {"<PAD>": 0, "<UNK>": 1}

for word in word_counts:
    vocab[word] = len(vocab)

# Maximum number of tokens
max_tokens = 100

# Convert text into numerical sequences
def enencoder(text):
    tokens = sentence_tokenize(text)
    numbers = [vocab.get(word, 1) for word in tokens]

    # Truncate longer responses
    numbers = numbers[:max_tokens]

    # Pad shorter responses
    numbers += [0] * (max_tokens - len(numbers))

    return numbers

# Encode training responses
x_train_encoded = np.array(
    [enencoder(response) for response in x_train]
)

# Encode testing responses
x_test_encoded = np.array(
    [enencoder(response) for response in x_test]
)

print("Vocabulary Size:", len(vocab))
print("Training Shape:", x_train_encoded.shape)
print("Testing Shape:", x_test_encoded.shape)

import torch
import torch.nn as nn

# Make results reproducible
torch.manual_seed(42)

# Define the RNN model using LSTM
class RNNClassifier(nn.Module):

    def __init__(self, vocab_size, embedding_dim,
                 hidden_dim, num_classes):
        super().__init__()

        # Convert token IDs into numerical vectors
        self.embedding = nn.Embedding(
            vocab_size,
            embedding_dim,
            padding_idx=0
        )

        # LSTM layer to process sequential text
        self.lstm = nn.LSTM(
            input_size=embedding_dim,
            hidden_size=hidden_dim,
            batch_first=True
        )

        # Final classification layer
        self.fc = nn.Linear(
            hidden_dim,
            num_classes
        )

    def forward(self, x):

        # Convert token IDs into embeddings
        x_embedded = self.embedding(x)

        # Process sequences through LSTM
        outputs, _ = self.lstm(x_embedded)

        # Find the last real token in each response
        lengths = (x != 0).sum(dim=1).clamp(min=1)

        batch_indices = torch.arange(
            x.size(0), device=x.device
        )

        # Select the last non-padding LSTM output
        last_output = outputs[
            batch_indices, lengths - 1
        ]

        # Generate classification scores
        x = self.fc(last_output)

        return x


# Create the RNN model
model = RNNClassifier(
    vocab_size=len(vocab),
    embedding_dim=32,
    hidden_dim=32,
    num_classes=3
)

# Convert training data into PyTorch tensors
x_train_tensor = torch.tensor(
    x_train_encoded,
    dtype=torch.long
)

# Test whether data passes through RNN
outputs = model(x_train_tensor)

print("RNN Output Shape:", outputs.shape)
print(model)





# RNN Training

# Convert training labels into PyTorch tensors
y_train_tensor = torch.tensor(
    y_train,
    dtype=torch.long
)

# Define the loss function
criterion = nn.CrossEntropyLoss()

# Define the optimizer
optimizer = torch.optim.Adam(
    model.parameters(),
    lr=0.001
)

# Set the number of epochs
epochs = 30

# Train the RNN
for epoch in range(epochs):

    model.train()

    # Clear previous gradients
    optimizer.zero_grad()

    # Generate predictions
    predictions = model(x_train_tensor)

    # Calculate the loss
    loss = criterion(
        predictions,
        y_train_tensor
    )

    # Calculate gradients
    loss.backward()

    # Update the model weights
    optimizer.step()

    # Display loss every 5 epochs
    if (epoch + 1) % 5 == 0:
        print(
            f"Epoch {epoch+1}/{epochs}, "
            f"Loss: {loss.item():.4f}"
        )


# RNN Evaluation

from sklearn.metrics import confusion_matrix, classification_report

# Convert testing data into tensors
x_test_tensor = torch.tensor(
    x_test_encoded,
    dtype=torch.long
)

y_test_tensor = torch.tensor(
    y_test,
    dtype=torch.long
)

# Switch model to evaluation mode
model.eval()

with torch.no_grad():

    # Predict training responses
    train_outputs = model(x_train_tensor)

    train_predictions = torch.argmax(
        train_outputs,
        dim=1
    )

    # Calculate training accuracy
    train_correct = (
        train_predictions == y_train_tensor
    ).sum().item()

    train_accuracy = train_correct / len(y_train_tensor)

    # Predict testing responses
    test_outputs = model(x_test_tensor)

    predicted_labels = torch.argmax(
        test_outputs,
        dim=1
    )

    # Calculate testing accuracy
    test_correct = (
        predicted_labels == y_test_tensor
    ).sum().item()

    test_accuracy = test_correct / len(y_test_tensor)

# Display the results
print("\nRNN Results:")
print(f"RNN Training Accuracy: {train_accuracy:.2%}")
print(f"RNN Testing Accuracy: {test_accuracy:.2%}")
print("Correct Predictions:", test_correct)

# Convert predictions to NumPy
predicted = predicted_labels.cpu().numpy()

# Display confusion matrix
print("\nRNN Confusion Matrix:")
print(
    confusion_matrix(
        y_test,
        predicted,
        labels=[0, 1, 2]
    )
)

# Display classification report
print("\nRNN Classification Report:")
print(
    classification_report(
        y_test,
        predicted,
        labels=[0, 1, 2],
        target_names=encoder.classes_,
        zero_division=0
    )
)
